/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package gui;
import java.awt.*;
import javax.swing.*;

public class ExamplrLabel_extends_Jframe {

    private static void ExampleLabel() {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }
    Jlabel label1;
    FlowLayout fl;
public ExamplrLabel_extends_Jframe(PopupMenu labrl1){
    Container b=getContenpane();
    label1 = new JLabel("Praktikum GUWI");
    b.add(labrl1);
    setLayout(new FlowLayout());
    setSize(300,100);
    show();
    }
public static void main(String[] args){
    Examplelabel 1 = new ExampleLabel();
}

    private Container getContenpane() {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    private void setLayout(FlowLayout flowLayout) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    private void setSize(int i, int i0) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    private void show() {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    private static class Jlabel {

        public Jlabel() {
        }
    }
}
