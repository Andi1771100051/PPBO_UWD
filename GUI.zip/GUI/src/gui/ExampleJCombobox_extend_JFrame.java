/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package gui;
import java.awt.*;
import javax.swing.JComboBox;
import javax.swing.JScrollPane;
/**
 *
 * @author ilckom
 */
public class ExampleJCombobox_extend_JFrame {
    private final JComboBox cbx;
    public ExampleJCombobox_extend_JFrame(){
        Container a = getContenPane();
        String[] items = {"komputer","mouse","Keyboad","hardis","printr"};
        cbx = new JComboBox(items);
        a.setLayout(new FlowLayout());
        a.add(cbx);
        Component add;
        add = a.add(new JScrollPane(cbx());
        setSize(300,190);
        show();
    }
    public static void main (String[] args){
        ExampleJComboBox x = new ExampleJComboBoc();
    }

    private Container getContenPane() {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    private Component cbx() {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    private void setSize(int i, int i0) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    private void show() {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    private static class ExampleJComboBox {

        public ExampleJComboBox() {
        }
    }

    private static class ExampleJComboBoc extends ExampleJComboBox {

        public ExampleJComboBoc() {
        }
    }
}
