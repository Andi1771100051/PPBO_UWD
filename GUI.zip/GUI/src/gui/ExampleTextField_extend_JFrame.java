/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package gui;
import java.awt.*;
import javax.swing.*;

public class ExampleTextField_extend_JFrame {
    private JTextField txt1;
    private JpasswordField pass1;
    private final JtextArea txtA1;
public ExampleTextField_extend_JFrame(){
    Container b =getContenPane();
    setLayout(new FlowLayout());
    txt1 = new JTextField(10);
    b.add(txt1);
        JPasswordField pss1 = new JPasswordField(10);
b.add(pss1);
txtA1 = new JTextArea(5,20);
b.add(txtA1);
setSize(300,160);
show();
}
public static void main(String[] args){
    ExampletextField a = new ExampleTextField();
}

    private Container getContenPane() {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    private void setLayout(FlowLayout flowLayout) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    private void setSize(int i, int i0) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    private void show() {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    private static class JtextArea {

        public JtextArea() {
        }
    }

    private static class JpasswordField {

        public JpasswordField() {
        }
    }

    private static class ExampletextField {

        public ExampletextField() {
        }
    }
}
